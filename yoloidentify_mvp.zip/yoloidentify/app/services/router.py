"""
模块名称：router
作用：根据粗分类结果决定是否进入细分判断，并从注册表选择对应的细分处理器。
使用方法：
  - next_stage, fine = route(image, coarse, registry, normal_category_name)
"""

from __future__ import annotations

from app.models.base import CoarsePrediction, FinePrediction
from app.services.judge_registry import JudgeRegistry


def route(
    image,
    coarse: CoarsePrediction,
    registry: JudgeRegistry,
    normal_category_name: str,
) -> tuple[str, FinePrediction | None]:
    if coarse.category_name == normal_category_name:
        return "coarse_only", None

    judge = registry.get(coarse.category_name)
    fine = judge.predict(image, coarse)
    return "fine_judge", fine

